﻿"""Mesh construction and STL/3MF writers.

No 3D CSG is required: cutter and stamp solids are built from watertight
extrusions and lofted annular profiles. Overlapping components are kept as
separate shells, which every slicer unions at slice time.
"""

from __future__ import annotations

import io
import math
import struct
import zipfile
from dataclasses import dataclass
from typing import Iterable, Sequence
from xml.sax.saxutils import escape

import numpy as np
from shapely import affinity
from shapely.geometry import LineString, MultiPolygon, Point, Polygon, box
from shapely.ops import nearest_points, unary_union
from shapely.geometry.polygon import orient

from .vendor.earcut import earcut


@dataclass
class Mesh:
    vertices: np.ndarray
    faces: np.ndarray

    def __post_init__(self) -> None:
        self.vertices = np.asarray(self.vertices, dtype=np.float64)
        self.faces = np.asarray(self.faces, dtype=np.int64)

    def append(self, other: "Mesh") -> "Mesh":
        if len(self.vertices) == 0:
            return other.copy()
        if len(other.vertices) == 0:
            return self.copy()
        offset = len(self.vertices)
        return Mesh(
            np.vstack([self.vertices, other.vertices]),
            np.vstack([self.faces, other.faces + offset]),
        )

    def copy(self) -> "Mesh":
        return Mesh(self.vertices.copy(), self.faces.copy())

    def merged(self, decimals: int = 6) -> "Mesh":
        """Merge coincident vertices so cap and wall seams are watertight."""
        if len(self.vertices) == 0 or len(self.faces) == 0:
            return self
        rounded = np.round(self.vertices, decimals=decimals)
        unique, inverse = np.unique(rounded, axis=0, return_inverse=True)
        faces = inverse[self.faces]
        keep = (
            (faces[:, 0] != faces[:, 1])
            & (faces[:, 1] != faces[:, 2])
            & (faces[:, 0] != faces[:, 2])
        )
        return Mesh(unique, faces[keep])

    def oriented(self) -> "Mesh":
        if len(self.faces) == 0:
            return self
        if self.signed_volume() < 0:
            return Mesh(self.vertices, self.faces[:, ::-1].copy())
        return self

    def orient_consistent(self) -> "Mesh":
        """Make adjacent triangles traverse shared edges in opposite directions.

        This is a tiny BFS orientation repair.  It is needed after merging cap
        and wall vertices because a closed mesh with one flipped cap is still
        watertight but slices badly.
        """
        if len(self.faces) == 0:
            return self
        faces = self.faces.copy()
        edge_map: dict[tuple[int, int], list[tuple[int, int]]] = {}
        for fi, f in enumerate(faces):
            for a, b in ((f[0], f[1]), (f[1], f[2]), (f[2], f[0])):
                key = (int(a), int(b)) if a < b else (int(b), int(a))
                direction = 1 if (int(a), int(b)) == key else -1
                edge_map.setdefault(key, []).append((fi, direction))
        visited = np.zeros(len(faces), dtype=bool)
        flips = np.zeros(len(faces), dtype=bool)
        for start in range(len(faces)):
            if visited[start]:
                continue
            visited[start] = True
            queue = [start]
            while queue:
                fi = queue.pop()
                f = faces[fi]
                for a, b in ((f[0], f[1]), (f[1], f[2]), (f[2], f[0])):
                    key = (int(a), int(b)) if a < b else (int(b), int(a))
                    raw_dir = 1 if (int(a), int(b)) == key else -1
                    effective = raw_dir * (-1 if flips[fi] else 1)
                    adj = edge_map.get(key, [])
                    if len(adj) != 2:
                        continue
                    for fj, neighbor_dir in adj:
                        if fj == fi or visited[fj]:
                            continue
                        desired = -effective
                        flips[fj] = neighbor_dir != desired
                        visited[fj] = True
                        queue.append(fj)
        faces[flips] = faces[flips][:, ::-1]
        out = Mesh(self.vertices, faces)
        return out.oriented()

    def signed_volume(self) -> float:
        if len(self.faces) == 0:
            return 0.0
        v = self.vertices
        f = self.faces
        a = v[f[:, 0]]
        b = v[f[:, 1]]
        c = v[f[:, 2]]
        return float(np.einsum("ij,ij->i", a, np.cross(b, c)).sum() / 6.0)

    def volume(self) -> float:
        return abs(self.signed_volume())

    @property
    def bounds(self) -> dict[str, list[float]]:
        if len(self.vertices) == 0:
            return {"min": [0, 0, 0], "max": [0, 0, 0]}
        return {
            "min": [float(x) for x in self.vertices.min(axis=0)],
            "max": [float(x) for x in self.vertices.max(axis=0)],
        }

    @property
    def triangles(self) -> int:
        return int(len(self.faces))

    def translated(self, offset: Sequence[float]) -> "Mesh":
        v = self.vertices.copy()
        v += np.asarray(offset, dtype=float)
        return Mesh(v, self.faces.copy())

    def stl_bytes(self) -> bytes:
        return mesh_to_stl(self)


def _triangle_area2(p: np.ndarray, q: np.ndarray, r: np.ndarray) -> float:
    return (q[0] - p[0]) * (r[1] - p[1]) - (r[0] - p[0]) * (q[1] - p[1])


def triangulate_polygon(poly: Polygon) -> tuple[np.ndarray, np.ndarray]:
    """Triangulate a Shapely polygon with holes using the vendored earcut."""
    if poly.is_empty:
        return np.zeros((0, 2)), np.zeros((0, 3), dtype=np.int64)
    poly = orient(poly, sign=1.0)
    rings: list[np.ndarray] = [np.asarray(poly.exterior.coords[:-1], dtype=float)]
    for interior in poly.interiors:
        rings.append(np.asarray(interior.coords[:-1], dtype=float))
    flat: list[float] = []
    hole_indices: list[int] = []
    cursor = 0
    for i, ring in enumerate(rings):
        if i > 0:
            hole_indices.append(cursor)
        flat.extend(ring.reshape(-1).tolist())
        cursor += len(ring)
    verts = np.asarray(flat, dtype=float).reshape(-1, 2)
    if len(verts) < 3:
        return np.zeros((0, 2)), np.zeros((0, 3), dtype=np.int64)
    try:
        faces = np.asarray(earcut(flat, hole_indices if hole_indices else None, 2), dtype=np.int64)
    except Exception:
        return np.zeros((0, 2)), np.zeros((0, 3), dtype=np.int64)
    if len(faces) % 3 != 0:
        return np.zeros((0, 2)), np.zeros((0, 3), dtype=np.int64)
    faces = faces.reshape(-1, 3)
    # Ensure every triangle is CCW in 2D.
    for i, tri in enumerate(faces):
        if _triangle_area2(verts[tri[0]], verts[tri[1]], verts[tri[2]]) < 0:
            faces[i] = tri[[0, 2, 1]]
    return verts, faces


def triangulate_rings(outer: np.ndarray, inner: np.ndarray) -> np.ndarray:
    """Triangulate an annulus, preserving every input boundary vertex."""
    flat: list[float] = []
    for ring in (outer, inner):
        flat.extend(np.asarray(ring, dtype=float).reshape(-1).tolist())
    try:
        faces = np.asarray(earcut(flat, [len(outer)] if len(inner) else None, 2), dtype=np.int64)
    except Exception:
        return np.zeros((0, 3), dtype=np.int64)
    if len(faces) % 3:
        return np.zeros((0, 3), dtype=np.int64)
    faces = faces.reshape(-1, 3)
    pts = np.vstack([outer, inner])
    for i, tri in enumerate(faces):
        a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
        if _triangle_area2(pts[a], pts[b], pts[c]) < 0:
            faces[i] = [a, c, b]
    return faces


def _jitter_ring(coords, seed: int) -> list[tuple[float, float]]:
    out: list[tuple[float, float]] = []
    for i, (x, y) in enumerate(coords):
        out.append((
            float(x) + 0.001 * math.sin((i + 1) * 1.71 + seed),
            float(y) + 0.001 * math.cos((i + 1) * 2.13 + seed),
        ))
    return out


def _jitter_polygon(poly: Polygon) -> Polygon:
    """Sub-micron jitter so earcut keeps every boundary vertex.

    Without it, earcut may collapse long collinear edges; the cap then has
    fewer boundary vertices than the side wall and the STL is not watertight.
    Holes that touch the outer ring are also inset by 0.08 mm; this is far
    below print resolution and makes line-art relief triangulate reliably.
    """
    ext = _jitter_ring(list(poly.exterior.coords[:-1]), 0.0)
    ext_poly = Polygon(ext)
    holes: list[list[tuple[float, float]]] = []
    for i, ring in enumerate(poly.interiors):
        hole_poly = Polygon(ring)
        # Only inset holes that touch or nearly touch the outer ring.  Insetting
        # every hole used to deform sharp interior cusps and could leave a
        # tiny open edge at the cusp.
        if ext_poly.distance(hole_poly) < 0.05:
            q = hole_poly.buffer(-0.08, join_style=2, mitre_limit=2.0)
            if q.is_empty or q.area < 0.02:
                continue
            if q.geom_type == "Polygon" and ext_poly.buffer(0.05).contains(q):
                holes.append(_jitter_ring(list(q.exterior.coords[:-1]), i + 1.0))
                continue
        holes.append(_jitter_ring(list(ring.coords[:-1]), i + 1.0))
    return Polygon(ext, holes)


def extrude_polygon(poly: Polygon | MultiPolygon, z0: float, height: float) -> Mesh:
    """Watertight extrusion of a polygon with holes."""
    if poly is None or poly.is_empty or height <= 0:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    if isinstance(poly, MultiPolygon):
        pieces = [p for p in poly.geoms if not p.is_empty and p.area > 1e-8]
        if not pieces:
            return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
        out = extrude_polygon(pieces[0], z0, height)
        for piece in pieces[1:]:
            out = out.append(extrude_polygon(piece, z0, height))
        return out
    poly = _jitter_polygon(poly)
    verts2d, faces = triangulate_polygon(poly)
    if len(faces) == 0:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    n = len(verts2d)
    z1 = z0 + height
    bottom = np.column_stack([verts2d, np.full(n, z0)])
    top = np.column_stack([verts2d, np.full(n, z1)])
    vertices = np.vstack([bottom, top])
    all_faces: list[list[int]] = []
    for tri in faces:
        all_faces.append([int(tri[0]), int(tri[2]), int(tri[1])])  # bottom normal down
        all_faces.append([int(tri[0]) + n, int(tri[1]) + n, int(tri[2]) + n])

    # Walls: exterior and holes.
    rings = [np.asarray(poly.exterior.coords[:-1], dtype=float)]
    rings.extend(np.asarray(r.coords[:-1], dtype=float) for r in poly.interiors)
    for ri, ring in enumerate(rings):
        m = len(ring)
        if m < 3:
            continue
        base = len(vertices)
        for i in range(m):
            x, y = ring[i]
            vertices = np.vstack([vertices, [x, y, z0], [x, y, z1]])
        reverse = ri > 0
        for i in range(m):
            j = (i + 1) % m
            a = base + i * 2
            b = base + j * 2
            c = b + 1
            d = a + 1
            if reverse:
                all_faces.append([a, c, b])
                all_faces.append([a, d, c])
            else:
                all_faces.append([a, b, c])
                all_faces.append([a, c, d])
    verts_arr = np.asarray(vertices, dtype=float)
    faces_arr = np.asarray(all_faces, dtype=np.int64)
    if len(faces_arr):
        tri = verts_arr[faces_arr]
        area2 = np.linalg.norm(
            np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1
        )
        faces_arr = faces_arr[area2 > 1e-9]
    return Mesh(verts_arr, faces_arr).merged().orient_consistent()


def _ring_array(
    ring: Iterable[tuple[float, float]], n: int, ref: tuple[float, float] | None = None
) -> np.ndarray:
    pts = np.asarray(list(ring), dtype=float)
    if len(pts) < 3:
        return np.zeros((0, 2))
    if np.allclose(pts[0], pts[-1]):
        pts = pts[:-1]
    # Consistent start: nearest point to a reference point.  Using the same
    # reference for outer and inner loops keeps the cap ring from twisting.
    if ref is None:
        c = pts.mean(axis=0)
        ref = (float(c[0] + max(1.0, np.ptp(pts[:, 0]))), float(c[1]))
    d = np.hypot(pts[:, 0] - ref[0], pts[:, 1] - ref[1])
    start = int(np.argmin(d))
    pts = np.roll(pts, -start, axis=0)
    closed = np.vstack([pts, pts[0]])
    seg = np.linalg.norm(np.diff(closed, axis=0), axis=1)
    total = float(seg.sum())
    if total <= 1e-9:
        return np.zeros((0, 2))
    cum = np.concatenate([[0.0], np.cumsum(seg)])
    targets = np.linspace(0, total, n, endpoint=False)
    out = np.zeros((n, 2), dtype=float)
    for i, t in enumerate(targets):
        k = int(np.searchsorted(cum, t, side="right") - 1)
        k = min(max(k, 0), len(seg) - 1)
        f = (t - cum[k]) / max(seg[k], 1e-12)
        out[i] = closed[k] + (closed[k + 1] - closed[k]) * f
    # Sub-micron anti-collinear jitter: earcut otherwise collapses long
    # straight edges to their endpoints, which breaks cap/wall connectivity.
    # 0.001 mm is far below any FDM or resin feature size.
    j = np.arange(n, dtype=float)
    out[:, 0] += 0.001 * np.sin(j * 1.71)
    out[:, 1] += 0.001 * np.cos(j * 2.13)
    return out


def _signed_area(ring: np.ndarray) -> float:
    if len(ring) < 3:
        return 0.0
    x = ring[:, 0]
    y = ring[:, 1]
    return float((x * np.roll(y, -1) - np.roll(x, -1) * y).sum() / 2)


def _ring_loft(layers: list[tuple[float, np.ndarray, np.ndarray]], segments: int = 160) -> Mesh:
    """Loft annular layers. Each layer = (z, outer_loop, inner_loop).

    The outer and inner loops are resampled to the same count, so the resulting
    outer and inner surfaces connect cleanly. This is what gives the cutter a
    single watertight wall with a stepped base and a sharpened tip.
    """
    if not layers:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    first_outer = _ring_array(layers[0][1], segments)
    if len(first_outer) == 0:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    ref = (float(first_outer[0, 0]), float(first_outer[0, 1]))
    cleaned: list[tuple[float, np.ndarray, np.ndarray]] = []
    for z, outer, inner in layers:
        o = _ring_array(outer, segments, ref)
        i = _ring_array(inner, segments, ref)
        if len(o) != segments or len(i) != segments:
            continue
        if _signed_area(o) < 0:
            o = o[::-1]
        if _signed_area(i) > 0:
            i = i[::-1]
        cleaned.append((float(z), o, i))
    if len(cleaned) < 2:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))

    n = segments
    verts: list[list[float]] = []
    faces: list[list[int]] = []
    for z, o, i in cleaned:
        for x, y in o:
            verts.append([float(x), float(y), z])
        for x, y in i:
            verts.append([float(x), float(y), z])
    # Outer surface: each layer pair.
    for k in range(len(cleaned) - 1):
        z0, o0, i0 = cleaned[k]
        z1, o1, i1 = cleaned[k + 1]
        if abs(z1 - z0) < 1e-9 and np.allclose(o0, o1, atol=1e-7):
            pass
        else:
            a = k * 2 * n
            b = (k + 1) * 2 * n
            for j in range(n):
                j2 = (j + 1) % n
                p0 = a + j
                p1 = a + j2
                q0 = b + j
                q1 = b + j2
                faces.append([p0, p1, q1])
                faces.append([p0, q1, q0])
        if not (abs(z1 - z0) < 1e-9 and np.allclose(i0, i1, atol=1e-7)):
            a = k * 2 * n + n
            b = (k + 1) * 2 * n + n
            for j in range(n):
                j2 = (j + 1) % n
                p0 = a + j
                p1 = a + j2
                q0 = b + j
                q1 = b + j2
                faces.append([p0, p1, q1])
                faces.append([p0, q1, q0])
    # Caps.  The anti-collinear jitter in _ring_array keeps every boundary
    # vertex in earcut's output, so cap boundary edges match the wall edges.
    for layer_index, _z, flip in ((0, cleaned[0][0], True), (len(cleaned) - 1, cleaned[-1][0], False)):
        base = layer_index * 2 * n
        _, o, i = cleaned[layer_index]
        f2 = triangulate_rings(o, i)
        for tri in f2:
            if flip:
                faces.append([base + int(tri[0]), base + int(tri[2]), base + int(tri[1])])
            else:
                faces.append([base + int(tri[0]), base + int(tri[1]), base + int(tri[2])])
    return Mesh(np.asarray(verts), np.asarray(faces, dtype=np.int64)).merged().orient_consistent()


def cutter_rings(
    outer: Polygon,
    thickness: float,
    base_width: float,
    tip_width: float,
    inset: float = 0.25,
    base_shape: str = "round",
):
    """Return base, blade and tip ring polygons for an outline."""
    if base_shape == "rect":
        # A tighter mitre limit avoids long spikes at acute corners.
        join_style, miter, segs = 2, 1.5, 1
    elif base_shape == "chamfer":
        join_style, miter, segs = 3, 2.0, 1
    else:
        join_style, miter, segs = 1, 2.0, 8
    expanded_base = outer.buffer(base_width, join_style=join_style, mitre_limit=miter, quad_segs=segs)
    base_ring = expanded_base.difference(outer.buffer(-inset, join_style=1, quad_segs=8))
    expanded_blade = outer.buffer(thickness, join_style=1, quad_segs=8)
    blade_ring = expanded_blade.difference(outer)
    expanded_tip = outer.buffer(max(0.2, tip_width), join_style=1, quad_segs=8)
    tip_ring = expanded_tip.difference(outer)
    return _ring_parts(base_ring), _ring_parts(blade_ring), _ring_parts(tip_ring)


def _curved_relief_layers(
    poly: Polygon, z0: float, height: float, curve: str
) -> list[tuple[Polygon, float, float]]:
    """Stacked inset layers that soften the top edge of a raised detail."""
    if poly.is_empty or height <= 0.01:
        return []
    curve = curve if curve in {"chamfer", "round"} else "none"
    if curve == "none":
        return [(poly, z0, height)]
    amount = min(0.9, max(0.25, height * 0.3))
    if curve == "chamfer":
        top = poly.buffer(-amount, join_style=1, quad_segs=8)
        # A thin line cannot be inset: keep it flat and at full height instead
        # of leaving a shortened or spiky half-profile.
        if top.is_empty or top.area < max(0.05, poly.area * 0.12):
            return [(poly, z0, height)]
        low = max(0.15, height - amount)
        return [
            (poly, z0, low),
            (top, z0 + low - 0.01, min(amount, height - low) + 0.01),
        ]
    # A two-stage loft reads as a rounded relief at normal print scale while
    # keeping a single, clean interface between the two shells.
    top = poly.buffer(-amount * 0.55, join_style=1, quad_segs=8)
    if top.is_empty or top.area < max(0.05, poly.area * 0.12):
        return [(poly, z0, height)]
    low = max(0.2, height * 0.65)
    return [
        (poly, z0, low),
        (top, z0 + low - 0.01, max(0.1, height - low) + 0.01),
    ]


def _ring_parts(geom) -> list[Polygon]:
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    if hasattr(geom, "geoms"):
        out: list[Polygon] = []
        for g in geom.geoms:
            out.extend(_ring_parts(g))
        return out
    return []


def _outline_band_parts(geom: Polygon | None, width: float) -> list[Polygon]:
    """Thin closed line around a shape, used for the shallow back marking."""
    if geom is None or geom.is_empty:
        return []
    half = max(0.25, float(width) / 2.0)
    outer = geom.buffer(half, join_style=1, quad_segs=8)
    inner = geom.buffer(-half, join_style=1, quad_segs=8)
    if outer.is_empty:
        return []
    band = outer.difference(inner) if not inner.is_empty else outer
    return [p for p in _ring_parts(band) if p.area > 0.002]


def _accent_extrude(poly: Polygon, z0: float, height: float) -> Mesh:
    """Extrude a thin colour inlay, cleaning the slivers of outline bands."""
    if poly is None or poly.is_empty or height <= 0.01:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    def closed(test: Mesh) -> bool:
        counts: dict[tuple[int, int], int] = {}
        for a, b, c in test.faces:
            for p, q in ((int(a), int(b)), (int(b), int(c)), (int(c), int(a))):
                key = (p, q) if p < q else (q, p)
                counts[key] = counts.get(key, 0) + 1
        return bool(counts) and all(value == 2 for value in counts.values())

    clean = poly
    last: Mesh | None = None
    for tolerance in (0.0, 0.005, 0.01, 0.02, 0.04):
        try:
            if tolerance > 0:
                clean = poly.simplify(tolerance, preserve_topology=True)
            if not clean.is_valid:
                clean = clean.buffer(0)
            if clean.is_empty:
                continue
            mesh = extrude_polygon(clean, z0, height)
            if len(mesh.faces):
                last = mesh
                if closed(mesh):
                    return mesh
        except Exception:
            continue
    return last if last is not None else extrude_polygon(poly, z0, height)


def _subdivide_flat(mesh: Mesh, iterations: int) -> Mesh:
    """Uniform 1-to-4 subdivision, used before wrapping onto a cylinder."""
    if iterations <= 0 or len(mesh.faces) == 0:
        return mesh
    verts = [tuple(v) for v in mesh.vertices]
    faces = [tuple(int(i) for i in f) for f in mesh.faces]
    for _ in range(iterations):
        cache: dict[tuple[int, int], int] = {}
        new_faces: list[tuple[int, int, int]] = []

        def midpoint(a: int, b: int) -> int:
            key = (a, b) if a < b else (b, a)
            cached = cache.get(key)
            if cached is not None:
                return cached
            pa = verts[a]
            pb = verts[b]
            verts.append(((pa[0] + pb[0]) / 2.0, (pa[1] + pb[1]) / 2.0, (pa[2] + pb[2]) / 2.0))
            idx = len(verts) - 1
            cache[key] = idx
            return idx

        for a, b, c in faces:
            ab = midpoint(a, b)
            bc = midpoint(b, c)
            ca = midpoint(c, a)
            new_faces.extend(((a, ab, ca), (ab, b, bc), (ca, bc, c), (ab, bc, ca)))
        faces = new_faces
    return Mesh(np.asarray(verts, dtype=float), np.asarray(faces, dtype=np.int64))


def _weld_vertices(mesh: Mesh, tolerance: float = 1e-6) -> Mesh:
    """Merge coincident vertices so adaptive subdivision keeps a closed mesh."""
    verts: list[tuple[float, float, float]] = []
    lookup: dict[tuple[int, int, int], int] = {}
    remap: list[int] = []
    for raw in mesh.vertices:
        key = tuple(int(round(float(c) / tolerance)) for c in raw)
        idx = lookup.get(key)
        if idx is None:
            idx = len(verts)
            lookup[key] = idx
            verts.append((float(raw[0]), float(raw[1]), float(raw[2])))
        remap.append(idx)
    faces: list[tuple[int, int, int]] = []
    for raw in mesh.faces:
        a, b, c = (remap[int(i)] for i in raw)
        if a == b or b == c or c == a:
            continue
        faces.append((a, b, c))
    return Mesh(np.asarray(verts, dtype=float), np.asarray(faces, dtype=np.int64))


def _adaptive_subdivide(
    mesh: Mesh,
    max_edge: float,
    *,
    max_faces: int = 240_000,
    max_iterations: int = 10,
) -> Mesh:
    """Split only triangles with long edges.

    Uniform subdivision explodes the face count on a large cylindrical sleeve.
    This keeps the small pattern edges intact while smoothing the broad,
    unobstructed parts of the surface.  Every pass splits whole shared edges,
    so neighbouring triangles stay conforming and the result remains closed.
    """
    if len(mesh.faces) == 0:
        return mesh
    welded = _weld_vertices(mesh)
    verts = [tuple(v) for v in welded.vertices]
    faces = [tuple(int(i) for i in f) for f in welded.faces]
    limit = max(1.0, float(max_edge))
    for _ in range(max_iterations):
        if len(faces) >= max_faces:
            break
        lengths: dict[tuple[int, int], float] = {}
        for a, b, c in faces:
            for p, q in ((a, b), (b, c), (c, a)):
                key = (p, q) if p < q else (q, p)
                if key in lengths:
                    continue
                pa = verts[key[0]]
                pb = verts[key[1]]
                lengths[key] = math.dist(pa, pb)
        marked = {edge for edge, length in lengths.items() if length > limit}
        if not marked:
            break
        midpoints: dict[tuple[int, int], int] = {}
        for a, b in sorted(marked):
            pa = verts[a]
            pb = verts[b]
            midpoints[(a, b)] = len(verts)
            verts.append((
                (pa[0] + pb[0]) / 2.0,
                (pa[1] + pb[1]) / 2.0,
                (pa[2] + pb[2]) / 2.0,
            ))

        def midpoint(a: int, b: int) -> int | None:
            return midpoints.get((a, b) if a < b else (b, a))

        new_faces: list[tuple[int, int, int]] = []
        for a, b, c in faces:
            ab = midpoint(a, b)
            bc = midpoint(b, c)
            ca = midpoint(c, a)
            count = int(ab is not None) + int(bc is not None) + int(ca is not None)
            if count == 0:
                new_faces.append((a, b, c))
            elif count == 1:
                if ab is not None:
                    new_faces.extend(((a, ab, c), (ab, b, c)))
                elif bc is not None:
                    new_faces.extend(((a, b, bc), (a, bc, c)))
                else:
                    new_faces.extend(((a, b, ca), (b, c, ca)))
            elif count == 2:
                if ab is not None and bc is not None:
                    new_faces.extend(((a, ab, c), (ab, b, bc), (ab, bc, c)))
                elif bc is not None and ca is not None:
                    new_faces.extend(((a, b, bc), (a, bc, ca), (bc, c, ca)))
                else:
                    new_faces.extend(((a, ab, ca), (ab, b, c), (ab, c, ca)))
            else:
                new_faces.extend((
                    (a, ab, ca),
                    (ab, b, bc),
                    (ca, bc, c),
                    (ab, bc, ca),
                ))
        faces = new_faces
    return _weld_vertices(
        Mesh(np.asarray(verts, dtype=float), np.asarray(faces, dtype=np.int64)),
        tolerance=1e-5,
    )


def _polygon_only(geom) -> Polygon | None:
    if geom is None or geom.is_empty:
        return None
    if isinstance(geom, MultiPolygon):
        geom = max(geom.geoms, key=lambda p: p.area)
    if not isinstance(geom, Polygon):
        return None
    if not geom.is_valid:
        geom = geom.buffer(0)
        if isinstance(geom, MultiPolygon):
            geom = max(geom.geoms, key=lambda p: p.area)
    if not isinstance(geom, Polygon) or geom.is_empty or geom.area <= 1e-6:
        return None
    return geom


def build_cutter(
    main: Polygon,
    *,
    blade_thickness: float,
    blade_depth: float,
    tip_width: float,
    chamfer_height: float,
    base_height: float,
    base_width: float,
    sharp_edge: bool = True,
    extra_blade: bool = False,
    extra_blade_depth: float = 0.0,
    extra_blade_thickness: float = 0.0,
    base_shape: str = "round",
    alignment: tuple[float, float, float] | None = None,
    waist_line: bool = False,
) -> Mesh:
    base_parts, blade_parts, tip_parts = cutter_rings(
        main, blade_thickness, base_width, tip_width, base_shape=base_shape
    )
    meshes: list[Mesh] = []
    used: set[int] = set()

    def waist_layers(
        layers: list[tuple[float, list[tuple[float, float]], list[tuple[float, float]]]],
        outer_ring: list[tuple[float, float]],
        inner_ring: list[tuple[float, float]],
        top: float,
    ) -> None:
        if not waist_line:
            return
        band_height = max(0.9, 0.25 * top)
        centre = top * 0.5
        low = max(base_height + 0.6, centre - band_height / 2.0)
        high = min(base_height + max(0.5, blade_depth) - 0.6, centre + band_height / 2.0)
        if high - low < 0.8:
            return
        depth = max(0.12, min(0.35, blade_thickness * 0.25))
        try:
            blade_poly = Polygon(outer_ring)
            outer = blade_poly.buffer(-depth, join_style=1, quad_segs=8)
            inner = Polygon(inner_ring)
            if outer.is_empty:
                return
            groove = outer.difference(inner)
            parts = _ring_parts(groove)
            if not parts:
                return
            piece = max(parts, key=lambda p: p.area)
            groove_outer = list(piece.exterior.coords[:-1])
            # Keep the original inner wall; only the outside is relieved.
            if piece.interiors:
                groove_inner = list(piece.interiors[0].coords[:-1])
            else:
                groove_inner = inner_ring
        except Exception:
            return
        layers.extend([
            (low, outer_ring, inner_ring),
            (low + 0.01, groove_outer, groove_inner),
            (high - 0.01, groove_outer, groove_inner),
            (high, outer_ring, inner_ring),
        ])
        layers.sort(key=lambda layer: layer[0])
    for base in base_parts:
        if not base.interiors:
            continue
        # Match the blade/tip ring that shares the same location.
        centre = base.centroid
        blade = _nearest(blade_parts, centre, used)
        tip = _nearest(tip_parts, centre, used)
        if alignment is not None:
            ax, ay, ar = alignment
            dimple = Point(ax, ay).buffer(max(0.4, ar), quad_segs=24)
            depth = min(0.5, max(0.15, base_height * 0.2))
            # A shallow dimple on the non-marking underside of the base.  It
            # is open only from below, so it never reaches the cutting face.
            bottom_poly = base.difference(dimple)
            if bottom_poly.is_empty:
                meshes.append(extrude_polygon(base, 0.0, base_height))
            else:
                meshes.append(extrude_polygon(bottom_poly, 0.0, depth))
                meshes.append(extrude_polygon(base, depth - 0.01, base_height - depth + 0.01))
            if blade is not None:
                outer_blade = list(blade.exterior.coords[:-1])
                inner_blade = list(blade.interiors[0].coords[:-1])
                blade_layers: list[tuple[float, list[tuple[float, float]], list[tuple[float, float]]]] = [
                    (max(0.01, base_height - 0.01), outer_blade, inner_blade),
                ]
                if sharp_edge and chamfer_height > 0.2 and tip is not None:
                    outer_tip = list(tip.exterior.coords[:-1])
                    inner_tip = list(tip.interiors[0].coords[:-1])
                    blade_layers.append((base_height + blade_depth - chamfer_height, outer_blade, inner_blade))
                    blade_layers.append((base_height + blade_depth, outer_tip, inner_tip))
                else:
                    blade_layers.append((base_height + blade_depth, outer_blade, inner_blade))
                waist_layers(blade_layers, outer_blade, inner_blade, base_height + blade_depth)
                meshes.append(_ring_loft(blade_layers).oriented())
            continue
        outer_base = list(base.exterior.coords[:-1])
        inner_base = list(base.interiors[0].coords[:-1])
        if blade is None:
            meshes.append(_ring_loft([
                (0.0, outer_base, inner_base),
                (base_height, outer_base, inner_base),
            ]).oriented())
            continue
        outer_blade = list(blade.exterior.coords[:-1])
        inner_blade = list(blade.interiors[0].coords[:-1])
        layers: list[tuple[float, list[tuple[float, float]], list[tuple[float, float]]]] = [
            (0.0, outer_base, inner_base),
            (base_height, outer_base, inner_base),
            (base_height, outer_blade, inner_blade),
        ]
        if sharp_edge and chamfer_height > 0.2 and tip is not None:
            outer_tip = list(tip.exterior.coords[:-1])
            inner_tip = list(tip.interiors[0].coords[:-1])
            layers.append((base_height + blade_depth - chamfer_height, outer_blade, inner_blade))
            layers.append((base_height + blade_depth, outer_tip, inner_tip))
        else:
            layers.append((base_height + blade_depth, outer_blade, inner_blade))
        waist_layers(layers, outer_blade, inner_blade, base_height + blade_depth)
        meshes.append(_ring_loft(layers).oriented())
    if not meshes:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    out = meshes[0]
    for m in meshes[1:]:
        out = out.append(m)
    if extra_blade and extra_blade_depth > 0.2 and extra_blade_thickness > 0.05:
        extra_ring = main.buffer(blade_thickness + extra_blade_thickness, join_style=1, quad_segs=8).difference(main)
        for p in _ring_parts(extra_ring):
            if p.area > 0.001:
                out = out.append(extrude_polygon(
                    p,
                    max(0.0, base_height - 0.25),
                    min(extra_blade_depth, max(0.5, blade_depth - 0.5)) + 0.25,
                ))
    return out.oriented()


def _nearest(polys: list[Polygon], point, used: set[int]) -> Polygon | None:
    best = None
    best_d = float("inf")
    best_i = -1
    for i, p in enumerate(polys):
        if i in used:
            continue
        d = p.centroid.distance(point)
        if d < best_d:
            best_d = d
            best = p
            best_i = i
    if best is not None:
        used.add(best_i)
        return best
    return None


def rounded_rect(w: float, h: float, r: float) -> Polygon:
    r = max(0.0, min(r, min(w, h) / 2))
    if r <= 0:
        return box(-w / 2, -h / 2, w / 2, h / 2)
    return box(-w / 2 + r, -h / 2 + r, w / 2 - r, h / 2 - r).buffer(r, join_style=1, quad_segs=6)


def build_multicutter(
    main: Polygon,
    *,
    blade_thickness: float,
    blade_depth: float,
    tip_width: float,
    chamfer_height: float,
    base_height: float,
    base_width: float,
    rows: int,
    cols: int,
    spacing: float,
    sharp_edge: bool = True,
    extra_blade: bool = False,
    extra_blade_depth: float = 0.0,
    extra_blade_thickness: float = 0.0,
    base_shape: str = "round",
    add_press_handle: bool = False,
    press_handle_length: float = 30.0,
    press_handle_width: float = 12.0,
    press_handle_position: float = 50.0,
    press_handle_shape: str = "rounded",
    press_handles_both_ends: bool = False,
    waist_line: bool = False,
) -> Mesh:
    """A batch cutter with one shared press plate and one hole per copy.

    Each copy keeps a proper blade ring, but the individual base rings are
    replaced by a single connected plate.  The plate also gives the press
    handle something solid to attach to, so the whole grid can be used with
    one hand without separate loose cutters.
    """
    rows = max(1, int(rows))
    cols = max(1, int(cols))
    spacing = max(0.0, float(spacing))
    outer = main.buffer(base_width, join_style=1, quad_segs=8)
    ob = outer.bounds
    cell_w = max(1.0, ob[2] - ob[0])
    cell_d = max(1.0, ob[3] - ob[1])
    pitch_x = cell_w + spacing
    pitch_y = cell_d + spacing
    centers = [
        ((c - (cols - 1) / 2.0) * pitch_x, (r - (rows - 1) / 2.0) * pitch_y)
        for r in range(rows)
        for c in range(cols)
    ]

    cells = [affinity.translate(main, dx, dy) for dx, dy in centers]
    outer_cells = [cell.buffer(base_width, join_style=1, quad_segs=8) for cell in cells]
    minx = min(p.bounds[0] for p in outer_cells) - 2.0
    miny = min(p.bounds[1] for p in outer_cells) - 2.0
    maxx = max(p.bounds[2] for p in outer_cells) + 2.0
    maxy = max(p.bounds[3] for p in outer_cells) + 2.0
    plate = rounded_rect(maxx - minx, maxy - miny, 8.0)
    plate = affinity.translate(plate, (minx + maxx) / 2.0, (miny + maxy) / 2.0)
    holes = [cell.buffer(-0.25, join_style=1, quad_segs=8) for cell in cells]
    plate = plate.difference(unary_union(holes))
    parts: list[Mesh] = []
    for piece in _ring_parts(plate):
        if piece.area > 0.05:
            parts.append(extrude_polygon(piece, 0.0, base_height))

    for cell in cells:
        _, blade_parts, tip_parts = cutter_rings(
            cell, blade_thickness, base_width, tip_width, base_shape=base_shape
        )
        for index, blade in enumerate(blade_parts):
            if not blade.interiors:
                continue
            outer_blade = list(blade.exterior.coords[:-1])
            inner_blade = list(blade.interiors[0].coords[:-1])
            tip = tip_parts[index] if index < len(tip_parts) else None
            layers: list[tuple[float, list[tuple[float, float]], list[tuple[float, float]]]] = [
                (max(0.01, base_height - 0.01), outer_blade, inner_blade),
            ]
            if sharp_edge and chamfer_height > 0.2 and tip is not None and tip.interiors:
                outer_tip = list(tip.exterior.coords[:-1])
                inner_tip = list(tip.interiors[0].coords[:-1])
                layers.append((base_height + blade_depth - chamfer_height, outer_blade, inner_blade))
                layers.append((base_height + blade_depth, outer_tip, inner_tip))
            else:
                layers.append((base_height + blade_depth, outer_blade, inner_blade))
            if waist_line:
                band_h = max(0.9, 0.25 * (base_height + blade_depth))
                low = max(base_height + 0.6, (base_height + blade_depth) * 0.5 - band_h / 2)
                high = min(base_height + blade_depth - 0.6, low + band_h)
                if high - low >= 0.8:
                    depth = max(0.12, min(0.35, blade_thickness * 0.25))
                    try:
                        outer = Polygon(outer_blade).buffer(-depth, join_style=1, quad_segs=8)
                        groove = outer.difference(Polygon(inner_blade))
                        pieces = _ring_parts(groove)
                        if pieces:
                            gp = max(pieces, key=lambda p: p.area)
                            go = list(gp.exterior.coords[:-1])
                            gi = list(gp.interiors[0].coords[:-1]) if gp.interiors else inner_blade
                            layers.extend([
                                (low, outer_blade, inner_blade),
                                (low + 0.01, go, gi),
                                (high - 0.01, go, gi),
                                (high, outer_blade, inner_blade),
                            ])
                            layers.sort(key=lambda layer: layer[0])
                    except Exception:
                        pass
            parts.append(_ring_loft(layers).oriented())
        if extra_blade and extra_blade_depth > 0.2 and extra_blade_thickness > 0.05:
            extra_ring = cell.buffer(blade_thickness + extra_blade_thickness, join_style=1, quad_segs=8).difference(cell)
            for p in _ring_parts(extra_ring):
                if p.area > 0.001:
                    parts.append(extrude_polygon(
                        p,
                        max(0.0, base_height - 0.25),
                        min(extra_blade_depth, max(0.5, blade_depth - 0.5)) + 0.25,
                    ))

    if add_press_handle:
        width = max(6.0, min(30.0, float(press_handle_width)))
        length = max(20.0, min(maxx - minx - 4.0, max(40.0, float(press_handle_length))))
        plate_center_y = (miny + maxy) / 2.0
        offset = (float(press_handle_position) - 50.0) / 50.0 * max(0.0, (maxy - miny - width) / 2.0 - 3.0)
        positions = [plate_center_y + offset]
        if press_handles_both_ends:
            positions.append(plate_center_y - offset)
        for cy in positions:
            if press_handle_shape == "rect":
                handle = box(-length / 2.0, -width / 2.0, length / 2.0, width / 2.0)
            elif press_handle_shape == "round":
                handle = rounded_rect(length, width, width / 2.0)
            else:
                handle = rounded_rect(length, width, width * 0.45)
            handle = affinity.translate(handle, (minx + maxx) / 2.0, cy)
            parts.append(extrude_polygon(handle, base_height - 0.05, 6.0))

    if not parts:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    out = parts[0]
    for part in parts[1:]:
        out = out.append(part)
    bounds = out.bounds
    out = out.translated([
        -(bounds["min"][0] + bounds["max"][0]) / 2.0,
        -(bounds["min"][1] + bounds["max"][1]) / 2.0,
        0.0,
    ])
    return out.oriented()


def build_stamp(
    main: Polygon,
    details: list[Polygon],
    *,
    back_height: float,
    relief: float,
    clearance: float,
    border: bool = True,
    border_width: float = 1.6,
    border_height: float = 0.0,
    alignment: tuple[float, float, float] | None = None,
    recessed: bool = False,
    detail_curve: str = "none",
    detail_grow: float = 0.0,
    backing: str = "outline",
    backing_padding: float = 2.0,
    grip: bool = False,
    grip_diameter: float = 20.0,
    grip_depth: float = 2.0,
    back_mark: bool = False,
    back_mark_width: float = 0.9,
    two_color: bool = False,
    color_parts: list[Mesh] | None = None,
) -> Mesh:
    if backing == "rect":
        b = main.bounds
        pad = max(0.0, float(backing_padding))
        stamp_poly = rounded_rect(
            max(2.0, b[2] - b[0] + pad * 2.0),
            max(2.0, b[3] - b[1] + pad * 2.0),
            min(6.0, pad + 2.0),
        )
        stamp_poly = affinity.translate(
            stamp_poly, (b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0
        )
    else:
        stamp_poly = main.buffer(-clearance, join_style=1, quad_segs=8)
        if stamp_poly.is_empty:
            stamp_poly = main.buffer(-min(0.3, clearance), join_style=1, quad_segs=8)
    if stamp_poly.is_empty:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    stamp_components = _ring_parts(stamp_poly)
    parts: list[Mesh] = []
    accent_start = len(color_parts) if color_parts is not None else 0
    raised_back = back_mark and len(details) > 24
    raised_marks: list[Polygon] = []
    raised_depth = 0.0

    def stamp_base(component: Polygon, height: float, mark_details: list[Polygon]) -> list[Mesh]:
        nonlocal raised_depth, raised_marks
        out: list[Mesh] = []
        gp = None
        if grip:
            cb = component.bounds
            gr = min(
                max(2.0, float(grip_diameter) / 2.0),
                max(1.0, min(cb[2] - cb[0], cb[3] - cb[1]) * 0.22),
            )
            gc = component.centroid
            gp = Point(gc.x, gc.y).buffer(gr, quad_segs=32)
            if not component.buffer(-0.5).contains(gp):
                gp = None
        gd = min(max(0.3, float(grip_depth)), max(0.3, height - 0.5)) if gp is not None else 0.0
        dimple = None
        dep = 0.0
        if alignment is not None:
            ax, ay, ar = alignment
            dimple = Point(ax, ay).buffer(max(0.4, ar), quad_segs=24)
            dep = min(0.4, max(0.12, height * 0.1))
            if not component.buffer(0.05).contains(dimple):
                dimple = None
                dep = 0.0
        if two_color and color_parts is not None and dimple is not None:
            # The orientation dot is an insert of the second colour, but it
            # stops short of the back surface so the circular dimple remains
            # visible instead of disappearing when the insert is flush.
            dot_depth = dep if dep > 0 else min(0.35, max(0.12, height * 0.1))
            dot_fill = max(0.08, dot_depth - min(0.18, dot_depth * 0.45))
            color_parts.append(extrude_polygon(dimple, 0.0, dot_fill))
        if gd > 0.2 and gp is not None:
            # The grip recess occupies the centre of the back face.  The
            # shallow identification mark would be hidden inside it, so keep
            # the grip clean instead of carving a fragile second pocket.
            bottom = component.difference(gp)
            if dimple is not None:
                bottom = bottom.difference(dimple)
            if not bottom.is_empty:
                out.append(extrude_polygon(bottom, 0.0, gd))
                out.append(extrude_polygon(component, gd - 0.01, height - gd + 0.01))
                return out

        mark_parts: list[Polygon] = []
        mark_depth = dep if dep > 0 else min(0.35, max(0.12, height * 0.1))
        # Very detailed line-art is kept as a shallow raised mark instead of a
        # subtraction.  Older GEOS builds can abort on the near-coincident
        # slivers created while carving dozens of 0.05 mm groove rings.  A
        # raised insert uses no fragile boolean difference and still prints
        # reliably in one or two colours.
        safe_back_mark = back_mark and not raised_back
        if raised_back or safe_back_mark:
            shapes: list[Polygon] = []
            edge_margin = max(0.6, back_mark_width * 1.6) if not raised_back else 0.6
            inner_ref = component.buffer(-edge_margin, join_style=1, quad_segs=8)
            # On an outline-backed stamp the plate is already an inset copy of
            # the silhouette, so follow that plate.  With a rectangular
            # backing, follow the actual artwork instead of the rectangle.
            if not inner_ref.is_empty:
                main_mark = (
                    main.intersection(inner_ref)
                    if backing == "rect"
                    else inner_ref
                )
                shapes.extend(_outline_band_parts(main_mark, back_mark_width))
                for detail in mark_details:
                    try:
                        clipped_detail = detail.intersection(inner_ref)
                    except Exception:
                        clipped_detail = detail
                    shapes.extend(_outline_band_parts(clipped_detail, back_mark_width))
            target = raised_marks if raised_back else mark_parts
            for shape in shapes:
                if raised_back:
                    for p in _ring_parts(shape):
                        if p.area > 0.002:
                            target.append(p)
                else:
                    safe = component.buffer(-0.3, join_style=1, quad_segs=8)
                    if safe.is_empty:
                        continue
                    try:
                        clipped = shape.intersection(safe)
                    except Exception:
                        continue
                    for p in _ring_parts(clipped):
                        if p.area > 0.002:
                            target.append(p)
            if dimple is not None:
                def clear_dimple(poly: Polygon) -> list[Polygon]:
                    try:
                        return _ring_parts(poly.difference(dimple))
                    except Exception:
                        return [poly]
                raised_marks = [q for p in raised_marks for q in clear_dimple(p)]
                mark_parts = [q for p in mark_parts for q in clear_dimple(p)]
            if raised_back and raised_marks:
                raised_depth = max(raised_depth, mark_depth)
            if not raised_back and two_color and mark_parts and color_parts is not None:
                for p in mark_parts:
                    color_parts.append(_accent_extrude(p, 0.0, mark_depth))
        if dimple is not None or mark_parts:
            groove_depth = mark_depth
            bottom = component
            if dimple is not None:
                bottom = bottom.difference(dimple)
            for mark in mark_parts:
                try:
                    bottom = bottom.difference(mark)
                except Exception:
                    continue
            if not bottom.is_empty:
                # Very thin grooves leave sub-micron slivers in earcut when
                # the stamp has a narrow neck.  Cleaning them keeps the
                # shallow marking layer watertight.
                bottom = bottom.simplify(0.01, preserve_topology=True)
                out.append(extrude_polygon(bottom, 0.0, groove_depth))
                out.append(extrude_polygon(component, groove_depth - 0.01, height - groove_depth + 0.01))
                return out
        out.append(extrude_polygon(component, 0.0, height))
        return out

    for stamp_component in stamp_components:
        kept_details: list[Polygon] = []
        grow = max(0.0, min(2.0, float(detail_grow)))
        grown_details = [
            d.buffer(grow / 2.0, join_style=1, quad_segs=8) if grow > 0.001 else d
            for d in details
        ]
        for d in grown_details:
            clipped = d.intersection(stamp_component)
            if clipped.is_empty:
                continue
            for p in _ring_parts(clipped):
                # Drop hairline islands and details that hug the outer edge.
                # They print as tall, fragile ridges that look like a second
                # border and never line up with the stamp frame.
                if p.area <= 0.15:
                    continue
                try:
                    if p.distance(stamp_component.exterior) < max(0.4, clearance * 0.25):
                        continue
                except Exception:
                    pass
                kept_details.append(p)
        depth = min(max(0.2, relief), max(0.2, back_height - 1.0))
        if recessed and kept_details:
            # Negative relief: the background is high and the artwork is a
            # shallow recess.  This leaves raised details in dough/fondant.
            plate_height = max(0.3, back_height - depth)
            parts.extend(stamp_base(stamp_component, plate_height, kept_details))
            cutouts = unary_union([d for d in grown_details if not d.is_empty])
            cover = stamp_component.difference(cutouts)
            for p in _ring_parts(cover):
                if p.area > 0.01:
                    parts.append(extrude_polygon(p, back_height - depth - 0.01, depth + 0.01))
            continue
        parts.extend(stamp_base(stamp_component, back_height, kept_details))
        if border and border_width > 0.2:
            # A true annular frame, built by subtracting an inset copy of the
            # plate.  Buffering the exterior line produced non-watertight
            # fragments on sharp SVG contours.
            inner_plate = stamp_component.buffer(
                -max(0.2, border_width), join_style=1, quad_segs=8
            )
            if inner_plate.is_empty:
                inner_plate = stamp_component.buffer(
                    -max(0.1, min(0.4, border_width / 2)), join_style=1, quad_segs=8
                )
            strip = stamp_component.difference(inner_plate) if not inner_plate.is_empty else stamp_component
            border_rise = (
                max(0.3, float(border_height))
                if border_height > 0.01
                else max(0.3, relief) + 0.25
            )
            for p in _ring_parts(strip):
                if p.area > 0.01:
                    parts.append(extrude_polygon(
                        p, back_height - min(0.25, border_rise * 0.5), border_rise
                    ))
        for p in kept_details:
            for layer, z0, height in _curved_relief_layers(
                p, back_height - 0.25, relief + 0.25, detail_curve
            ):
                parts.append(extrude_polygon(layer, z0, height))
    if not parts:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    out = parts[0]
    for p in parts[1:]:
        out = out.append(p)
    if raised_back and raised_marks:
        # Move the stamp body up by the mark thickness and put the raised
        # illustration underneath it, resting on the print bed.
        out = out.translated([0.0, 0.0, raised_depth])
        mark_meshes = [
            _accent_extrude(p, 0.0, raised_depth + 0.05)
            for p in raised_marks
        ]
        if two_color and color_parts is not None:
            for index in range(accent_start, len(color_parts)):
                color_parts[index] = color_parts[index].translated(
                    [0.0, 0.0, raised_depth]
                )
            color_parts.extend(mark_meshes)
        else:
            for mark_mesh in mark_meshes:
                out = out.append(mark_mesh)
    return out


def build_imprint(
    main: Polygon,
    details: list[Polygon],
    *,
    blade_thickness: float,
    blade_depth: float,
    tip_width: float,
    chamfer_height: float,
    base_height: float,
    base_width: float,
    imprint_depth: float,
    base_shape: str = "round",
    sharp_edge: bool = True,
    alignment: tuple[float, float, float] | None = None,
    detail_curve: str = "none",
    detail_grow: float = 0.0,
    waist_line: bool = False,
    extra_blade: bool = False,
    extra_blade_depth: float = 0.0,
    extra_blade_thickness: float = 0.0,
    invert: bool = False,
    edges_only: bool = False,
    base_inset: float = 1.2,
    edge_width: float = 1.2,
    back_mark: bool = False,
    back_mark_width: float = 0.9,
    two_color: bool = False,
    color_parts: list[Mesh] | None = None,
) -> Mesh:
    cutter = build_cutter(
        main,
        blade_thickness=blade_thickness,
        blade_depth=blade_depth,
        tip_width=tip_width,
        chamfer_height=chamfer_height,
        base_height=base_height,
        base_width=base_width,
        sharp_edge=sharp_edge,
        extra_blade=extra_blade,
        extra_blade_depth=extra_blade_depth,
        extra_blade_thickness=extra_blade_thickness,
        base_shape=base_shape,
        alignment=alignment,
        waist_line=waist_line,
    )
    grow = max(0.0, min(2.0, float(detail_grow)))
    sources: list[Polygon] = []
    for d in details:
        source = d.buffer(grow / 2.0, join_style=1, quad_segs=8) if grow > 0.001 else d
        for p in _ring_parts(source):
            if p.area > 0.002:
                sources.append(p)
    if edges_only:
        line_w = max(0.4, float(edge_width))
        wall_h = max(1.0, min(max(1.0, blade_depth - 1.0), imprint_depth + 2.0))
        parts = [cutter]
        for p in sources:
            ring = p.buffer(line_w / 2.0, join_style=1, quad_segs=8).difference(
                p.buffer(-line_w / 2.0, join_style=1, quad_segs=8)
            )
            if ring.is_empty:
                ring = p
            for q in _ring_parts(ring):
                if q.area > 0.01:
                    parts.append(extrude_polygon(q, max(0.0, base_height - 0.2), wall_h))
        return _append_all(parts)
    floor_poly = main.buffer(-max(0.3, float(base_inset)), join_style=2)
    if floor_poly.is_empty:
        return cutter

    def marked_floor(poly: Polygon, top: float) -> list[Mesh]:
        if not back_mark or len(details) > 24:
            return [extrude_polygon(poly, 0.0, top)]
        depth = min(0.35, max(0.12, base_height * 0.1))
        shapes: list[Polygon] = []
        reference = poly.buffer(-max(0.2, back_mark_width * 0.5), join_style=1, quad_segs=8)
        if not reference.is_empty:
            shapes.extend(_outline_band_parts(reference, back_mark_width))
        if len(details) <= 24:
            for detail in details:
                try:
                    clipped = detail.intersection(poly)
                except Exception:
                    clipped = detail
                for p in _ring_parts(clipped):
                    shapes.extend(_outline_band_parts(p, back_mark_width))
        if not shapes:
            return [extrude_polygon(poly, 0.0, top)]
        safe = poly.buffer(-max(0.2, back_mark_width * 0.5), join_style=1, quad_segs=8)
        if safe.is_empty:
            return [extrude_polygon(poly, 0.0, top)]
        mark_parts = []
        for shape in shapes:
            try:
                clipped = shape.intersection(safe)
            except Exception:
                continue
            for p in _ring_parts(clipped):
                if p.area > 0.002:
                    mark_parts.append(p)
        if not mark_parts:
            return [extrude_polygon(poly, 0.0, top)]
        bottom = poly
        for mark in mark_parts:
            try:
                bottom = bottom.difference(mark)
            except Exception:
                continue
        if bottom.is_empty:
            return [extrude_polygon(poly, 0.0, top)]
        bottom = bottom.simplify(0.01, preserve_topology=True)
        if two_color and color_parts is not None:
            for mark in mark_parts:
                color_parts.append(_accent_extrude(mark, 0.0, depth))
        return [
            extrude_polygon(bottom, 0.0, depth),
            extrude_polygon(poly, depth - 0.01, top - depth + 0.01),
        ]

    if two_color and color_parts is not None and alignment is not None:
        ax, ay, ar = alignment
        dot = Point(ax, ay).buffer(max(0.4, ar), quad_segs=24)
        dot_depth = min(0.5, max(0.15, base_height * 0.2))
        dot_fill = max(0.08, dot_depth - min(0.18, dot_depth * 0.45))
        color_parts.append(extrude_polygon(dot, 0.0, dot_fill))

    floor_z = max(1.0, base_height + blade_depth - imprint_depth)
    if invert:
        carve = max(0.3, min(float(imprint_depth), max(0.4, floor_z - 0.6)))
        detail_union = unary_union(sources).intersection(floor_poly) if sources else None
        base_poly = floor_poly.buffer(-0.1, join_style=1, quad_segs=8)
        if base_poly.is_empty:
            base_poly = floor_poly
        out = cutter
        for floor_piece in marked_floor(base_poly, max(0.4, floor_z - carve + 0.2)):
            out = out.append(floor_piece)
        top = floor_poly.difference(detail_union) if detail_union is not None else floor_poly
        for p in _ring_parts(top):
            if p.area > 0.01:
                out = out.append(extrude_polygon(p, floor_z - carve, carve))
        return out
    out = cutter
    for floor_piece in marked_floor(floor_poly, floor_z):
        out = out.append(floor_piece)
    ceiling = floor_z + min(imprint_depth, blade_depth - 1)
    for source in sources:
        clipped = source.intersection(floor_poly)
        if clipped.is_empty:
            continue
        for p in _ring_parts(clipped):
            if p.area <= 0.002:
                continue
            height = max(0.15, ceiling - (floor_z - 0.25))
            for layer, z0, layer_height in _curved_relief_layers(
                p, floor_z - 0.25, height, detail_curve
            ):
                out = out.append(extrude_polygon(layer, z0, layer_height))
    return out


def build_sandwich(
    main: Polygon,
    *,
    blade_thickness: float,
    blade_depth: float,
    tip_width: float,
    chamfer_height: float,
    base_height: float,
    base_width: float,
    seal_width: float,
    gap: float,
    dent_size: float,
    dent_spacing: float,
    dent_depth: float,
    dent_shape: str = "round",
    dent_round: bool = False,
    dent_radius: float = 1.0,
    offset_outward: bool = False,
    base_shape: str = "round",
    sharp_edge: bool = True,
    alignment: tuple[float, float, float] | None = None,
    waist_line: bool = False,
) -> Mesh:
    """Cutter with an integrated CookieCAD-style sealing band.

    The outer blade cuts the sandwich and the lower inner band presses the
    layers together.  A thin shelf at the bottom joins the band to the cutter
    so the tool is one printable piece.  The optional centre stamp is a
    separate part built by the engine.
    """
    cutter = build_cutter(
        main,
        blade_thickness=blade_thickness,
        blade_depth=blade_depth,
        tip_width=tip_width,
        chamfer_height=chamfer_height,
        base_height=base_height,
        base_width=base_width,
        base_shape=base_shape,
        sharp_edge=sharp_edge,
        alignment=alignment,
        waist_line=waist_line,
    )
    width = max(0.8, float(seal_width))
    gap = max(0.0, float(gap))
    seal_outer = (
        main.buffer(gap, join_style=1, quad_segs=8)
        if offset_outward
        else main.buffer(-max(0.2, gap), join_style=1, quad_segs=8)
    )
    if seal_outer.is_empty:
        seal_outer = main.buffer(-0.2, join_style=1, quad_segs=8)
    seal_inner = seal_outer.buffer(-width, join_style=1, quad_segs=8)
    for _ in range(3):
        if not seal_inner.is_empty or seal_outer.is_empty:
            break
        width = max(0.4, width * 0.5)
        seal_inner = seal_outer.buffer(-width, join_style=1, quad_segs=8)
    seal_ring = (
        seal_outer.difference(seal_inner)
        if not seal_outer.is_empty and not seal_inner.is_empty
        else None
    )
    seal_height = max(2.0, base_height + blade_depth * 0.55)
    parts = [cutter]

    # Narrow shelf in the gap, overlapping both the cutter base and the seal
    # band.  It keeps the tool printable as one piece without blocking the
    # cutting edge.
    if seal_ring is not None and not seal_outer.is_empty:
        if offset_outward:
            connector = seal_outer.difference(
                main.buffer(max(0.2, base_width), join_style=1, quad_segs=8)
            )
        else:
            connector_outer = main.buffer(min(1.2, max(0.4, base_width * 0.35)), join_style=1, quad_segs=8)
            connector = connector_outer.difference(seal_outer)
        for p in _ring_parts(connector):
            if p.area > 0.01:
                parts.append(extrude_polygon(p, 0.0, max(1.0, base_height * 0.6)))

        for p in _ring_parts(seal_ring):
            if p.area > 0.01:
                parts.append(extrude_polygon(p, 0.0, seal_height))

    # Crimping dents distributed evenly around the middle of the band.
    if seal_ring is not None:
        for path_poly in _ring_parts(seal_outer.buffer(-width * 0.5, join_style=1, quad_segs=8)):
            if path_poly.is_empty:
                continue
            path = path_poly.exterior
            per = max(0.5, dent_spacing)
            n = max(4, int(path.length / per))
            r = max(0.4, dent_size / 2.0)
            for i in range(n):
                u = (i + 0.5) / n
                pt = path.interpolate(u, normalized=True)
                prev_pt = path.interpolate((u - 0.35 / n) % 1.0, normalized=True)
                next_pt = path.interpolate((u + 0.35 / n) % 1.0, normalized=True)
                tx, ty = next_pt.x - prev_pt.x, next_pt.y - prev_pt.y
                tl = math.hypot(tx, ty) or 1.0
                nx, ny = ty / tl, -tx / tl
                if (pt.x - path_poly.centroid.x) * nx + (pt.y - path_poly.centroid.y) * ny < 0:
                    nx, ny = -nx, -ny
                if dent_shape == "triangle":
                    bump: Polygon = Polygon([
                        (pt.x + nx * r, pt.y + ny * r),
                        (pt.x - ny * r * 0.9, pt.y + nx * r * 0.9),
                        (pt.x + ny * r * 0.9, pt.y - nx * r * 0.9),
                    ])
                elif dent_shape == "square":
                    h = r * 0.82
                    bump = box(-h, -h, h, h)
                    bump = affinity.rotate(bump, math.degrees(math.atan2(ty, tx)), origin=(0, 0))
                    bump = affinity.translate(bump, pt.x, pt.y)
                else:
                    bump = Point(pt.x, pt.y).buffer(r, quad_segs=16)
                if dent_round and dent_shape != "round":
                    bump = bump.buffer(max(0.1, float(dent_radius)), join_style=1, quad_segs=8)
                if not bump.is_valid:
                    bump = bump.buffer(0)
                parts.append(extrude_polygon(bump, seal_height - 0.2, max(0.3, dent_depth)))

    return _append_all(parts).oriented()


def build_roller(
    main: Polygon,
    details: list[Polygon] | None = None,
    *,
    diameter: float,
    length: float,
    relief: float,
    source_scale: float = 1.0,
    rim_height: float = 1.2,
    bore: float,
    repeats_around: int,
    repeats_along: int,
    rim: float,
    pattern: str = "grid",
    margin: float = 0.0,
    rotate: bool = False,
    invert: bool = False,
    back: float = 0.0,
    remove_edge: bool = False,
    depth_curve: str = "none",
    pattern_mode: str = "drawing",
) -> Mesh:
    """Hollow texture roller with wrapped, repeated and curved pattern tiles."""
    radius = max(4.0, diameter / 2)
    back = max(0.0, min(8.0, float(back)))
    outer_radius = radius + back
    inner = 0.0 if bore <= 0.05 else max(0.4, min(radius - 0.8, bore / 2))
    tube = Point(0, 0).buffer(outer_radius, quad_segs=64)
    if inner > 0.0:
        tube = tube.difference(Point(0, 0).buffer(inner, quad_segs=48))
    parts = [extrude_polygon(tube, -length / 2, length)]
    around = max(1, int(repeats_around))
    along = max(1, int(repeats_along))
    # Brick and mirror tiles need an even count around the cylinder so the
    # pattern closes cleanly at the seam.
    if pattern in {"brick", "mirror"} and around > 1 and around % 2 == 1:
        around += 1
    cell_w = 2 * math.pi * radius / around
    cell_h = length / along
    margin = max(0.0, min(float(margin), min(cell_w, cell_h) * 0.3))
    usable_w = max(1.0, cell_w - margin * 2.0)
    usable_h = max(1.0, cell_h - margin * 2.0)

    source_details = [d for d in (details or []) if d is not None and not d.is_empty]

    # Apply the same transform to the silhouette and its interior details so
    # they stay registered.  Scaling each detail around its own centre was the
    # cause of the floating/misplaced relief lines.
    pivot = main.centroid
    b = main.bounds
    bw = max(1e-6, b[2] - b[0])
    bh = max(1e-6, b[3] - b[1])
    fit = min(usable_w / bw, usable_h / bh) * 0.99 * max(0.1, min(1.0, float(source_scale)))

    def prepare(geom: Polygon) -> Polygon:
        g = affinity.translate(geom, -pivot.x, -pivot.y)
        if rotate:
            g = affinity.rotate(g, 90, origin=(0, 0))
        return affinity.scale(g, fit, fit, origin=(0, 0))

    tile = prepare(main)
    tile_b = tile.bounds
    offset_x = -(tile_b[0] + tile_b[2]) / 2.0
    offset_y = -(tile_b[1] + tile_b[3]) / 2.0
    tile = affinity.translate(tile, offset_x, offset_y)
    tile_b = tile.bounds
    tile_details: list[Polygon] = []
    for detail in source_details:
        transformed = affinity.translate(prepare(detail), offset_x, offset_y)
        clipped_detail = transformed.intersection(tile)
        for p in _ring_parts(clipped_detail):
            if p.area > 0.02:
                tile_details.append(p)

    # Drawing mode follows the complete drawing: the outer outline plus every
    # interior detail.  Silhouette mode keeps the filled shape and raises the
    # details on top.  "Remove outer edge" drops the silhouette outline while
    # retaining the interior linework.
    line_drawing = pattern_mode == "drawing"
    edge_w = max(0.8, min(2.5, max(0.3, relief) * 1.2))
    detail_grow = max(0.05, min(0.3, max(0.3, relief) * 0.15))
    separate_details: list[Polygon] = []
    if line_drawing:
        line_shapes: list[Polygon] = []
        if not remove_edge:
            outer_band = tile.buffer(edge_w / 2.0, join_style=1, quad_segs=8).difference(
                tile.buffer(-edge_w / 2.0, join_style=1, quad_segs=8)
            )
            line_shapes.extend(p for p in _ring_parts(outer_band) if p.area > 0.01)
        line_shapes.extend(
            p
            for d in tile_details
            for p in _ring_parts(d.buffer(detail_grow, join_style=1, quad_segs=8))
            if p.area > 0.02
        )
        pattern_tile: Polygon | MultiPolygon = (
            unary_union(line_shapes) if line_shapes else tile
        )
    elif remove_edge and tile_details:
        pattern_tile = unary_union(tile_details)
    else:
        pattern_tile = tile
        if not invert:
            separate_details = tile_details
    if pattern_tile.is_empty:
        pattern_tile = tile

    def mapped(mesh: Mesh, theta0: float, axial0: float, mirror: bool) -> Mesh:
        verts = mesh.vertices.copy()
        faces = mesh.faces.copy()
        if mirror:
            verts[:, 0] *= -1.0
            faces = faces[:, ::-1].copy()
        out = np.zeros_like(verts)
        for i, (x, y, z) in enumerate(verts):
            angle = theta0 + x / max(radius, 1e-6)
            radial = radius + z - 0.2
            out[i] = (radial * math.cos(angle), radial * math.sin(angle), axial0 + y)
        return Mesh(out, faces)

    # Large flat triangles would cut straight chords through the cylinder and
    # look like random facets in the 3D preview.  Adaptive edge subdivision
    # keeps the curved silhouette smooth without multiplying every small
    # interior detail by the same factor.
    max_edge = max(2.2, min(3.6, radius * 0.12))

    def wrapped(poly: Polygon, z0: float, height: float,
                theta0: float, axial0: float, mirror: bool,
                refine: bool = True) -> list[Mesh]:
        if poly.is_empty or height <= 0.01:
            return []
        mesh = extrude_polygon(poly, z0, height)
        if len(mesh.faces) == 0:
            return []
        if refine:
            mesh = _adaptive_subdivide(mesh, max_edge, max_faces=60_000)
        return [mapped(mesh, theta0, axial0, mirror)]

    if invert:
        # Engraved rollers need one continuous raised sleeve.  Building a
        # separate raised rectangle for every pattern cell produced visible
        # flat panels, gaps and a polygonal silhouette.  Here the pattern is a
        # set of vector holes cut out of a single cylindrical sleeve, so the
        # base cylinder shows through as a clean, continuous recess.
        sheet_w = 2.0 * math.pi * radius
        sheet = box(-sheet_w / 2.0, -length / 2.0, sheet_w / 2.0, length / 2.0)
        cut_pattern = pattern_tile.buffer(-0.08, join_style=1, quad_segs=8)
        if cut_pattern.is_empty:
            cut_pattern = pattern_tile

        hole_parts: list[Polygon] = []
        tile_holes: list[tuple[float, float, bool]] = []
        # Put the unwrapped-sheet seam in the empty margin between motifs
        # whenever the layout allows it, so a motif is not cut in half at the
        # back of the roller.
        seam_phase = math.pi / around if around % 2 == 0 else 0.0
        for ia in range(around):
            for il in range(along):
                theta0 = (2.0 * math.pi * ia) / around + seam_phase
                axial0 = -length / 2.0 + (il + 0.5) * cell_h
                if pattern == "brick" and il % 2 == 1:
                    theta0 += math.pi / around
                mirror = pattern == "mirror" and (ia + il) % 2 == 1
                tile_holes.append((theta0, axial0, mirror))
                hole = cut_pattern
                if mirror:
                    hole = affinity.scale(hole, -1.0, 1.0, origin=(0.0, 0.0))
                for shift in (-sheet_w, 0.0, sheet_w):
                    translated = affinity.translate(
                        hole, theta0 * radius + shift, axial0
                    )
                    hole_parts.extend(_ring_parts(translated))

        holes = unary_union(hole_parts) if hole_parts else Polygon()
        sleeve_shape = sheet.difference(holes)
        sleeve_height = max(0.3, relief) + 0.25
        sleeve_edge = max(2.8, min(4.2, radius * 0.16))
        for sleeve_piece in _ring_parts(sleeve_shape):
            if sleeve_piece.area <= 0.02:
                continue
            # Earcut can leave sub-micron slivers between nearly touching
            # holes; those slivers create open edges in the extruded cap.
            # A tolerance far below print resolution removes them cleanly.
            clean_piece = sleeve_piece.simplify(0.01, preserve_topology=True)
            if clean_piece.is_empty or clean_piece.area <= 0.02:
                continue
            sleeve_mesh = extrude_polygon(clean_piece, 0.0, sleeve_height)
            sleeve_mesh = _adaptive_subdivide(
                sleeve_mesh, sleeve_edge, max_faces=170_000
            )
            verts = sleeve_mesh.vertices.copy()
            out = np.zeros_like(verts)
            for i, (x, y, z) in enumerate(verts):
                angle = x / max(radius, 1e-6)
                radial = radius + back - 0.2 + z
                out[i] = (
                    radial * math.cos(angle),
                    radial * math.sin(angle),
                    y,
                )
            parts.append(Mesh(out, sleeve_mesh.faces.copy()))

        if not line_drawing and not remove_edge:
            # Interior linework remains raised from the cylinder floor inside
            # the recess, instead of disappearing with the silhouette hole.
            detail_height = max(0.3, min(0.75, relief * 0.55))
            for theta0, axial0, mirror in tile_holes:
                for detail in tile_details:
                    parts.extend(wrapped(
                        detail, back, detail_height,
                        theta0, axial0, mirror, refine=True,
                    ))
    else:
        for ia in range(around):
            for il in range(along):
                theta0 = (2.0 * math.pi * ia) / around
                axial0 = -length / 2.0 + (il + 0.5) * cell_h
                if pattern == "brick" and il % 2 == 1:
                    theta0 += math.pi / around
                mirror = pattern == "mirror" and (ia + il) % 2 == 1
                for layer_poly, z0, height in _curved_relief_layers(
                    pattern_tile, back, max(0.3, relief) + 0.25, depth_curve
                ):
                    parts.extend(wrapped(layer_poly, z0, height, theta0, axial0, mirror))
                for detail in separate_details:
                    detail_height = max(0.35, min(0.9, relief * 0.4))
                    for layer_poly, z0, height in _curved_relief_layers(
                        detail,
                        back + max(0.3, relief) - 0.05,
                        detail_height,
                        depth_curve,
                    ):
                        parts.extend(wrapped(
                            layer_poly, z0, height, theta0, axial0, mirror
                        ))
    # End rims.
    if rim > 0:
        rim_width = max(0.5, rim)
        rim_extra = max(0.3, min(3.0, float(rim_height)))
        for z0 in (-length / 2, length / 2 - rim_width):
            r_out = Point(0, 0).buffer(outer_radius + rim_extra, quad_segs=64)
            # Overlap the tube wall slightly instead of sharing its surface:
            # coincident faces make the combined mesh non-manifold.
            r_in = Point(0, 0).buffer(max(0.5, outer_radius - 0.5), quad_segs=64)
            ring = r_out.difference(r_in)
            parts.append(extrude_polygon(ring, z0, rim_width))
    out = parts[0]
    for p in parts[1:]:
        out = out.append(p)
    # The roller is printed standing up: move its lowest face onto Z=0.
    lowest = out.bounds["min"][2]
    if lowest != 0:
        out = out.translated([0.0, 0.0, -lowest])
    return out


def build_stencil(
    main: Polygon,
    details: list[Polygon] | None = None,
    *,
    width: float,
    height: float,
    rows: int,
    cols: int,
    spacing: float,
    thickness: float,
    shape_size: float = 0.0,
    margin: float = 3.0,
    pattern: str = "grid",
    layout: str = "grid",
    bridges: bool = True,
    bridge_width: float = 1.2,
    line_width: float = 1.2,
) -> Mesh:
    """Flat stencil sheet with the complete drawing repeated as openings.

    Solid silhouettes are cut as one opening.  When the artwork has interior
    details, the stencil cuts the outer outline and every interior detail so
    the result is the whole drawing, not only the outer silhouette.  A thin
    backing bridge keeps interior islands attached.
    """
    rows = max(1, int(rows))
    cols = max(1, int(cols))
    width = max(10.0, float(width))
    height = max(10.0, float(height))
    margin = max(0.0, min(float(margin), min(width, height) * 0.35))
    line_w = max(0.4, float(line_width))
    sheet = box(-width / 2, -height / 2, width / 2, height / 2)
    details = [d for d in (details or []) if d is not None and not d.is_empty]
    b = main.bounds
    bw = max(1e-6, b[2] - b[0])
    bh = max(1e-6, b[3] - b[1])
    available_w = max(4.0, width - margin * 2)
    available_h = max(4.0, height - margin * 2)
    if layout == "dimensions":
        target = float(shape_size) if shape_size > 0 else min(available_w, available_h) * 0.2
        target = max(2.0, target)
        cols = max(1, int((available_w + spacing) // (target + spacing)))
        rows = max(1, int((available_h + spacing) // (target + spacing)))
        shape_size = target
    elif layout == "computed" and shape_size > 0:
        spacing = max(0.5, min(
            (available_w - cols * shape_size) / (cols - 1) if cols > 1 else spacing,
            (available_h - rows * shape_size) / (rows - 1) if rows > 1 else spacing,
        ))
    cell_w = available_w / cols
    cell_h = available_h / rows
    gap = max(0.5, spacing) + (line_w if details else 0.0)
    fit = min((cell_w - gap) / bw, (cell_h - gap) / bh)
    if shape_size and shape_size > 0:
        fit = min(fit, float(shape_size) / max(bw, bh))
    scale = max(0.05, fit)

    pivot = main.centroid
    scaled_main = affinity.scale(main, scale, scale, origin=pivot)
    pb = scaled_main.bounds
    offset_x = -(pb[0] + pb[2]) / 2.0
    offset_y = -(pb[1] + pb[3]) / 2.0
    pattern_main = affinity.translate(scaled_main, offset_x, offset_y)
    pattern_details = [
        affinity.translate(affinity.scale(d, scale, scale, origin=pivot), offset_x, offset_y)
        for d in details
    ]

    if pattern_details:
        # Follow the original drawing: cut the interior details.  The outer
        # border is only the cutter silhouette, so it is not added here.
        pattern_cut = unary_union([
            d.buffer(max(0.05, line_w * 0.25), join_style=1, quad_segs=8)
            for d in pattern_details
        ])
    else:
        pattern_cut = pattern_main

    cb = pattern_cut.bounds
    half_pattern_w = (cb[2] - cb[0]) / 2.0
    half_pattern_h = (cb[3] - cb[1]) / 2.0
    cuts: list[Polygon] = []
    for r in range(rows):
        for c in range(cols):
            cx = -available_w / 2 + (c + 0.5) * cell_w
            cy = -available_h / 2 + (r + 0.5) * cell_h
            if pattern == "diagonal" and r % 2 == 1:
                cx += cell_w / 2
                if cx + half_pattern_w > width / 2 - margin:
                    cx -= cell_w
            elif pattern == "random":
                phase = (r * cols + c + 1) * 1.618
                cx += math.sin(phase) * cell_w * 0.14
                cy += math.cos(phase * 1.37) * cell_h * 0.14
            cuts.append(affinity.translate(pattern_cut, cx, cy))
    holes = unary_union(cuts)
    result = sheet.difference(holes)
    pieces = [p for p in _ring_parts(result) if p.area > 0.05]
    if not pieces:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    pieces.sort(key=lambda p: -p.area)
    if bridges and len(pieces) > 1:
        connected = pieces[0]
        for island in pieces[1:]:
            try:
                a, c = nearest_points(connected, island)
                bridge = LineString([a, c]).buffer(
                    max(0.5, float(bridge_width)) / 2, cap_style=2, join_style=2
                )
                connected = unary_union([connected, island, bridge])
            except Exception:
                connected = unary_union([connected, island])
        pieces = [p for p in _ring_parts(connected) if p.area > 0.05]
    parts: list[Mesh] = []
    for p in pieces:
        parts.append(extrude_polygon(p, 0.0, max(0.6, thickness)))
    if not parts:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    return _append_all(parts)


def build_topper(
    main: Polygon,
    details: list[Polygon],
    *,
    thickness: float,
    relief: float,
    pin_length: float,
    pin_width: float,
    backing: float = 0.0,
    pin_position: float = 0.0,
    invert: bool = False,
    detail_curve: str = "none",
) -> Mesh:
    """Flat cake topper with a tapered printable stake in the same plane."""
    base_poly = main.buffer(max(0.0, float(backing)), join_style=1, quad_segs=8)
    if base_poly.is_empty:
        base_poly = main
    parts = [extrude_polygon(base_poly, 0.0, max(1.0, thickness))]
    clipped_details: list[Polygon] = []
    for d in details:
        clipped = d.intersection(main)
        for p in _ring_parts(clipped):
            if p.area > 0.15:
                clipped_details.append(p)
    relief_height = max(0.3, relief) + 0.2
    if invert and clipped_details:
        # Raise the background and leave the artwork at base level.  This is the
        # same physical result as an inverted stamp without needing 3D CSG.
        # Use the original detail rings for the cut-out: re-intersecting them
        # can introduce near-duplicate vertices that make earcut create cracks.
        cover = base_poly.difference(unary_union([d for d in details if not d.is_empty]))
        for p in _ring_parts(cover):
            if p.area > 0.15:
                for layer, z0, height in _curved_relief_layers(
                    p, thickness - 0.2, relief_height, detail_curve
                ):
                    parts.append(extrude_polygon(layer, z0, height))
    else:
        for p in clipped_details:
            for layer, z0, height in _curved_relief_layers(
                p, thickness - 0.2, relief_height, detail_curve
            ):
                parts.append(extrude_polygon(layer, z0, height))
    b = base_poly.bounds
    pin_w = max(1.0, float(pin_width))
    pin_l = max(2.0, float(pin_length))
    usable = max(0.0, (b[2] - b[0]) - pin_w)
    cx = (float(pin_position) / 100.0) * usable / 2
    pin_strip = box(cx - pin_w / 2, b[1] - 1.0, cx + pin_w / 2, b[3] + 1.0)
    slice_poly = base_poly.intersection(pin_strip)
    attach_y = slice_poly.bounds[1] if not slice_poly.is_empty else b[1]
    tip_w = min(pin_w, max(1.0, pin_w * 0.72))
    chamfer = min(0.8, pin_l * 0.25)
    shoulder_y = attach_y - pin_l + min(6.0, pin_l * 0.4)
    tip_y = attach_y - pin_l
    pin = Polygon([
        (cx - pin_w / 2, attach_y + 0.5),
        (cx + pin_w / 2, attach_y + 0.5),
        (cx + pin_w / 2, shoulder_y),
        (cx + tip_w / 2, tip_y + chamfer),
        (cx + tip_w * 0.35, tip_y),
        (cx - tip_w * 0.35, tip_y),
        (cx - tip_w / 2, tip_y + chamfer),
        (cx - pin_w / 2, shoulder_y),
    ])
    if not pin.is_valid:
        pin = pin.buffer(0)
    if pin.is_empty or pin.area <= 0.01:
        return parts[0] if len(parts) == 1 else _append_all(parts)
    parts.append(extrude_polygon(pin, 0.0, max(1.0, thickness)))
    return _append_all(parts)


def build_cake_pop_tray(
    main: Polygon,
    *,
    length: float,
    height: float,
    depth_percent: float,
    clearance: float,
    margin: float,
    rotation: float,
    stick_hole: float,
) -> Mesh:
    """Support tray with a shaped pocket and a stick passage through the base."""
    rotated = affinity.rotate(main, rotation, origin="center")
    b = rotated.bounds
    shape_w = max(2.0, b[2] - b[0])
    shape_h = max(2.0, b[3] - b[1])
    cx = (b[0] + b[2]) / 2.0
    cy = (b[1] + b[3]) / 2.0
    hole = rotated.buffer(max(0.2, clearance), join_style=1, quad_segs=8)
    hole = affinity.translate(hole, -cx, -cy + length / 2.0)
    tray_w = shape_w + margin * 2.0
    footprint_h = shape_h + margin * 2.0 + max(0.0, length)
    outer = rounded_rect(tray_w, footprint_h, min(8.0, min(tray_w, footprint_h) * 0.18))
    tray_height = max(4.0, float(height))
    pocket = min(max(0.8, tray_height - 0.8), tray_height * max(0.1, min(0.9, depth_percent / 100.0)))
    bottom_h = max(0.6, tray_height - pocket)
    parts: list[Mesh] = []
    stick = Point(0.0, length / 2.0).buffer(max(0.0, stick_hole) / 2.0, quad_segs=32)
    bottom_poly = outer.difference(stick) if stick_hole > 0.1 else outer
    for p in _ring_parts(bottom_poly):
        if p.area > 0.02:
            parts.append(extrude_polygon(p, 0.0, bottom_h))
    top_poly = outer.difference(hole)
    for p in _ring_parts(top_poly):
        if p.area > 0.02:
            parts.append(extrude_polygon(p, bottom_h - 0.01, pocket + 0.01))
    if not parts:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    out = parts[0]
    for part in parts[1:]:
        out = out.append(part)
    return out.oriented()


def build_cake_pop(
    main: Polygon,
    details: list[Polygon],
    *,
    mold_height: float,
    mold_wall: float,
    base_height: float,
    stick_hole: float,
    hole_clearance: float,
    plunger_clearance: float,
    plunger_back: float,
    plunger_relief: float,
    plunger_face: str = "imprint",
) -> tuple[Mesh, Mesh]:
    """A two-piece cake-pop mould: open tray plus fitted plunger.

    The tray is a closed-bottom cavity with a central stick channel.  The
    plunger is a shallow stamp that fits inside the cavity.  Both pieces are
    built from watertight prisms; overlapping shells are unioned by the
    slicer at print time.
    """
    main = main.buffer(0)
    outer = main.buffer(max(0.8, mold_wall), join_style=1, quad_segs=8)
    if outer.is_empty:
        outer = main
    hole_r = max(1.0, (stick_hole + hole_clearance * 2) / 2)
    c = main.centroid
    stick = Point(c.x, c.y).buffer(hole_r, quad_segs=32)
    floor_poly = outer.difference(stick)
    base = extrude_polygon(floor_poly, 0.0, max(1.0, base_height))
    wall_ring = outer.difference(main)
    walls = [
        extrude_polygon(p, max(0.0, base_height - 0.25), max(0.5, mold_height) + 0.25)
        for p in _ring_parts(wall_ring)
        if p.area > 0.01
    ]
    tray = _append_all([base] + walls)
    # The plunger is deliberately slightly smaller than the cavity.
    plunger_poly = main.buffer(-max(0.2, plunger_clearance), join_style=1, quad_segs=8)
    if plunger_poly.is_empty:
        plunger_poly = main.buffer(-0.2, join_style=1, quad_segs=8)
    plunger_parts = [extrude_polygon(plunger_poly, 0.0, max(1.0, plunger_back))]
    face = str(plunger_face) if str(plunger_face) in {"imprint", "outline", "none"} else "imprint"
    relief_h = max(0.3, plunger_relief) + 0.2
    if face == "imprint":
        for d in details:
            clipped = d.intersection(plunger_poly)
            for p in _ring_parts(clipped):
                if p.area > 0.15:
                    plunger_parts.append(extrude_polygon(
                        p, max(0.0, plunger_back - 0.2), relief_h
                    ))
    elif face == "outline":
        inner = plunger_poly.buffer(-0.8, join_style=1, quad_segs=8)
        dense = plunger_poly.difference(inner) if not inner.is_empty else None
        if dense is None or dense.is_empty or dense.area <= 0.02:
            dense = plunger_poly.boundary.buffer(0.5, cap_style=1, join_style=1)
            dense = dense.intersection(plunger_poly)
        for p in _ring_parts(dense):
            if p.area > 0.02:
                plunger_parts.append(extrude_polygon(
                    p, max(0.0, plunger_back - 0.2), relief_h
                ))
    # Side grip tab, printed in the same plane as the plunger.
    pb = plunger_poly.bounds
    grip_len = max(10.0, min(26.0, (pb[3] - pb[1]) * 0.35))
    grip_wid = max(7.0, min(16.0, (pb[2] - pb[0]) * 0.18))
    grip = rounded_rect(grip_len, grip_wid, grip_wid / 2)
    grip = affinity.translate(grip, pb[2] - 1.5 + grip_len / 2, (pb[1] + pb[3]) / 2)
    plunger_parts.append(extrude_polygon(grip, 0.0, max(1.0, plunger_back)))
    return tray, _append_all(plunger_parts)


def build_cake_pop_two(
    main: Polygon,
    details: list[Polygon],
    *,
    mold_height: float,
    mold_wall: float,
    base_height: float,
    stick_hole: float,
    hole_clearance: float,
    plunger_clearance: float,
    plunger_back: float,
    plunger_relief: float,
    plunger_face: str = "imprint",
) -> tuple[Mesh, Mesh, Mesh]:
    """Cake-pop mould with a two-piece plunger: stamp face + back plate."""
    tray, _old_plunger = build_cake_pop(
        main, details,
        mold_height=mold_height,
        mold_wall=mold_wall,
        base_height=base_height,
        stick_hole=stick_hole,
        hole_clearance=hole_clearance,
        plunger_clearance=plunger_clearance,
        plunger_back=plunger_back,
        plunger_relief=plunger_relief,
        plunger_face=plunger_face,
    )
    plunger_poly = main.buffer(-max(0.2, plunger_clearance), join_style=1, quad_segs=8)
    if plunger_poly.is_empty:
        plunger_poly = main.buffer(-0.2, join_style=1, quad_segs=8)
    face_poly = plunger_poly.buffer(-0.2, join_style=1, quad_segs=8)
    if face_poly.is_empty:
        face_poly = plunger_poly
    face_h = max(1.2, min(3.0, plunger_back))
    face_parts = [extrude_polygon(face_poly, 0.0, face_h)]
    face = str(plunger_face) if str(plunger_face) in {"imprint", "outline", "none"} else "imprint"
    relief_h = max(0.3, plunger_relief) + 0.2
    if face == "imprint":
        for d in details:
            for p in _ring_parts(d.intersection(face_poly)):
                if p.area > 0.15:
                    face_parts.append(extrude_polygon(p, face_h - 0.2, relief_h))
    elif face == "outline":
        inner = face_poly.buffer(-0.8, join_style=1, quad_segs=8)
        ring = face_poly.difference(inner) if not inner.is_empty else None
        if ring is None or ring.is_empty or ring.area <= 0.02:
            ring = face_poly.boundary.buffer(0.5, cap_style=1, join_style=1).intersection(face_poly)
        for p in _ring_parts(ring):
            if p.area > 0.02:
                face_parts.append(extrude_polygon(p, face_h - 0.2, relief_h))

    back_h = max(2.0, plunger_back)
    back_outer = plunger_poly.buffer(1.2, join_style=1, quad_segs=8)
    back_parts = [extrude_polygon(back_outer, 0.0, back_h)]
    rim_outer = plunger_poly.buffer(0.9, join_style=1, quad_segs=8)
    rim_inner = plunger_poly.buffer(-0.15, join_style=1, quad_segs=8)
    rim = rim_outer.difference(rim_inner) if not rim_inner.is_empty else rim_outer
    for p in _ring_parts(rim):
        if p.area > 0.01:
            back_parts.append(extrude_polygon(p, max(0.0, back_h - 0.2), 1.0))
    pb = back_outer.bounds
    grip_len = max(10.0, min(24.0, (pb[3] - pb[1]) * 0.32))
    grip_wid = max(7.0, min(16.0, (pb[2] - pb[0]) * 0.18))
    grip = rounded_rect(grip_len, grip_wid, grip_wid / 2)
    grip = affinity.translate(grip, pb[2] - 1.5 + grip_len / 2, (pb[1] + pb[3]) / 2)
    back_parts.append(extrude_polygon(grip, 0.0, back_h))
    return tray, _append_all(face_parts), _append_all(back_parts)


def _append_all(parts: list[Mesh]) -> Mesh:
    if not parts:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64))
    out = parts[0]
    for p in parts[1:]:
        out = out.append(p)
    return out


def build_practice(
    main: Polygon,
    *,
    thickness: float,
    wall_height: float,
    wall_width: float,
) -> Mesh:
    """Shallow solid-backed practice cookie with a wall following the outline."""
    # A practice cookie is a solid surface for practicing icing.  Interior
    # source holes would turn it into a ring and defeat that purpose.
    solid = Polygon(main.exterior.coords)
    base = extrude_polygon(solid, 0.0, max(1.0, thickness))
    ring = solid.buffer(max(0.4, wall_width), join_style=1, quad_segs=8).difference(solid)
    parts = [base]
    for p in _ring_parts(ring):
        if p.area > 0.01:
            parts.append(extrude_polygon(p, 0.0, max(thickness, wall_height)))
    out = parts[0]
    for p in parts[1:]:
        out = out.append(p)
    return out


def _map_mesh(mesh: Mesh, mapper) -> Mesh:
    if len(mesh.faces) == 0:
        return mesh
    vertices = np.asarray([mapper(tuple(v)) for v in mesh.vertices], dtype=float)
    return Mesh(vertices, mesh.faces.copy()).orient_consistent()


def build_bookmark(
    main: Polygon,
    details: list[Polygon],
    *,
    width: float,
    height: float,
    thickness: float,
    corner: float,
    margin: float,
    hole: bool,
    hole_diameter: float,
    hole_margin: float,
    relief: float,
    style: str = "relief",
    line_width: float = 0.4,
    gap: float = 0.6,
    bridge: float = 4.0,
    flare: float = 6.0,
    lip: float = 1.0,
    hinge_thickness: float = 0.6,
) -> tuple[Mesh, Mesh]:
    """Two-piece page clip: a debossed base and a raised press.

    The base has the drawing recessed into its inner face and a shallow central
    socket.  The press is a flat plate with the matching raised drawing and a
    central pivot; its outer face is also debossed.  Both pieces print flat,
    have no tall borders and no through-holes, and clamp the page between them.
    """
    W = max(20.0, float(width))
    H = max(20.0, float(height))
    T = max(1.2, float(thickness))
    m = max(2.0, min(float(margin), min(W, H) * 0.3))
    relief_h = max(0.0, min(2.5, float(relief)))
    if relief_h <= 0.01:
        relief_h = 0.8
    outer_h = min(0.5, T * 0.22)
    gap = max(0.2, min(3.0, float(gap)))
    pivot_d = max(2.0, min(10.0, float(bridge)))
    pivot_h = max(0.4, min(2.5, float(lip)))
    tab = max(0.0, min(12.0, float(flare)))
    plate = rounded_rect(W, H, corner)

    detail_parts = [d for d in details if d is not None and not d.is_empty]
    if style == "none":
        mark = None
    elif style == "line":
        lw = max(0.8, min(2.0, float(line_width) * 2.0))
        if detail_parts:
            mark = unary_union([
                d.boundary.buffer(lw / 2, cap_style=1, join_style=1)
                for d in detail_parts
            ])
        else:
            mark = main.boundary.buffer(lw / 2, cap_style=1, join_style=1)
    else:
        mark = unary_union(detail_parts) if detail_parts else main
    if mark is not None and not mark.is_empty:
        available_w = max(2.0, W - m * 2.0)
        available_h = max(2.0, H - m * 2.0)
        mb = mark.bounds
        mw = max(1e-6, mb[2] - mb[0])
        mh = max(1e-6, mb[3] - mb[1])
        scale = min(available_w / mw, available_h / mh) * 0.98
        mark = affinity.scale(mark, scale, scale, origin="center")
        mb = mark.bounds
        mark = affinity.translate(mark, -(mb[0] + mb[2]) / 2.0, -(mb[1] + mb[3]) / 2.0)
    else:
        mark = None

    def plate_base(
        region: Polygon,
        height: float,
        mark_top: Polygon | None,
        mark_bottom: Polygon | None,
        socket: Polygon | None,
        press: bool,
    ) -> list[Mesh]:
        parts: list[Mesh] = []
        bottom = region
        if mark_bottom is not None and not mark_bottom.is_empty:
            bottom = bottom.difference(mark_bottom)
        for p in _ring_parts(bottom):
            if p.area > 0.01:
                parts.append(extrude_polygon(p, 0.0, outer_h))
        parts.append(extrude_polygon(region, outer_h - 0.01, height - outer_h + 0.01))
        if mark_top is not None or socket is not None:
            top = region
            if mark_top is not None and not mark_top.is_empty:
                top = top.difference(mark_top)
            if socket is not None and not socket.is_empty:
                top = top.difference(socket)
            # The top layer is the full thickness; the recesses are the
            # difference between this layer and the base.  Build the floor
            # only where the top is removed by taking the difference from the
            # full plate; the floor is already part of the full extrusion.
            for p in _ring_parts(top):
                if p.area > 0.01:
                    parts.append(extrude_polygon(p, height - 0.01, T + 0.01))
        return parts

    # Base: debossed drawing on the top, shallow decorative deboss below and a
    # central socket for the press pivot.
    pivot = Point(0.0, 0.0).buffer(pivot_d / 2.0, quad_segs=32)
    base_parts: list[Mesh] = []
    base_parts.append(extrude_polygon(plate, 0.0, T - relief_h))
    base_top = plate
    if mark is not None and not mark.is_empty:
        base_top = base_top.difference(mark)
    base_top = base_top.difference(pivot)
    for p in _ring_parts(base_top):
        if p.area > 0.01:
            base_parts.append(extrude_polygon(p, T - relief_h, relief_h))
    # Decorative deboss on the outside of the base.
    outer_bottom = plate if mark is None else plate.difference(mark)
    # Rebuild the bottom outer layer without covering the decorative recess.
    base_parts = []
    for p in _ring_parts(outer_bottom):
        if p.area > 0.01:
            base_parts.append(extrude_polygon(p, 0.0, outer_h))
    base_parts.append(extrude_polygon(plate, outer_h - 0.01, T - relief_h - outer_h + 0.01))
    for p in _ring_parts(base_top):
        if p.area > 0.01:
            base_parts.append(extrude_polygon(p, T - relief_h, relief_h))
    base = _append_all(base_parts).oriented()

    # Press: slightly smaller plate; raised inner drawing and pivot; debossed
    # decorated outer face.
    press_poly = plate.buffer(-gap, join_style=1, quad_segs=8)
    if press_poly.is_empty:
        press_poly = plate.buffer(-0.3, join_style=1, quad_segs=8)
    mirrored_mark = (
        affinity.scale(mark, -1, 1, origin=(0, 0))
        if mark is not None and not mark.is_empty
        else None
    )
    press_parts: list[Mesh] = []
    outer = press_poly if mirrored_mark is None else press_poly.difference(mirrored_mark)
    for p in _ring_parts(outer):
        if p.area > 0.01:
            press_parts.append(extrude_polygon(p, 0.0, outer_h))
    press_parts.append(extrude_polygon(
        press_poly, outer_h - 0.01, T - outer_h + 0.01
    ))
    if mirrored_mark is not None:
        for p in _ring_parts(mirrored_mark.intersection(press_poly)):
            if p.area > 0.02:
                for layer, z0, hgt in _curved_relief_layers(
                    p, T - 0.03, max(0.25, relief_h - 0.2), "round"
                ):
                    press_parts.append(extrude_polygon(layer, z0, hgt))
    for p in _ring_parts(pivot.intersection(press_poly)):
        if p.area > 0.01:
            press_parts.append(extrude_polygon(p, T - 0.03, pivot_h))
    press = _append_all(press_parts).oriented()
    return base, press


def mesh_to_stl(mesh: Mesh) -> bytes:
    if len(mesh.faces) == 0:
        return b""
    v = mesh.vertices
    f = mesh.faces
    triangles = v[f]
    normals = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
    lengths = np.linalg.norm(normals, axis=1)
    lengths[lengths == 0] = 1
    normals = normals / lengths[:, None]
    header = b"CalicoCutters - cortador y sello para impresion 3D".ljust(80, b" ")
    buf = io.BytesIO()
    buf.write(header)
    buf.write(struct.pack("<I", len(f)))
    for n, tri in zip(normals, triangles):
        vals = [float(n[0]), float(n[1]), float(n[2])]
        for p in tri:
            vals.extend([float(p[0]), float(p[1]), float(p[2])])
        buf.write(struct.pack("<12fH", *vals, 0))
    return buf.getvalue()


def _escape(value: str) -> str:
    return escape(value, {'"': "&quot;"})


def three_mf_bytes(parts: list[tuple[str, Mesh, str, tuple[float, float, float]]], title: str = "CalicoCutters") -> bytes:
    materials = "".join(
        f'<base name="{_escape(name)}" displaycolor="{color}" />'
        for name, _mesh, color, _off in parts
    )
    color_slots: dict[str, int] = {}
    for _name, _mesh, color, _off in parts:
        if color not in color_slots:
            color_slots[color] = len(color_slots) + 1

    def is_accent(name: str) -> bool:
        return "Dibujo a color" in name or "Punto a color" in name

    def mesh_xml(mesh: Mesh) -> str:
        verts = "".join(
            f'<vertex x="{x:.4f}" y="{y:.4f}" z="{z:.4f}"/>'
            for x, y, z in mesh.vertices
        )
        tris = "".join(
            f'<triangle v1="{int(a)}" v2="{int(b)}" v3="{int(c)}"/>'
            for a, b, c in mesh.faces
        )
        return f"<vertices>{verts}</vertices><triangles>{tris}</triangles>"

    # Colour parts after a body belong to that same object.  Bambu Studio loads
    # a single object with coloured sub-parts much more reliably than a row of
    # separate top-level objects.
    groups: list[list[int]] = []
    for index, (name, _mesh, _color, _offset) in enumerate(parts):
        if is_accent(name) and groups:
            groups[-1].append(index)
        else:
            groups.append([index])

    objects: list[str] = []
    items: list[str] = []
    model_settings: list[str] = []
    next_id = 2
    for group in groups:
        first = parts[group[0]]
        base_name, _base_mesh, base_color, base_offset = first
        if len(group) == 1:
            name, mesh, color, offset = first
            oid = next_id
            next_id += 1
            objects.append(
                f'<object id="{oid}" type="model" name="{_escape(name)}" pid="1" pindex="{group[0]}">'
                f'<mesh>{mesh_xml(mesh)}</mesh></object>'
            )
            tx, ty, tz = offset
            items.append(f'<item objectid="{oid}" transform="1 0 0 0 1 0 0 0 1 {tx:.4f} {ty:.4f} {tz:.4f}"/>')
            model_settings.append(
                f'<object id="{oid}"><metadata key="name" value="{_escape(name)}"/>'
                f'<metadata key="extruder" value="{color_slots.get(color, 1)}"/></object>'
            )
            continue

        component_xml: list[str] = []
        for part_index in group:
            name, mesh, color, offset = parts[part_index]
            oid = next_id
            next_id += 1
            objects.append(
                f'<object id="{oid}" type="model" name="{_escape(name)}" pid="1" pindex="{part_index}">'
                f'<mesh>{mesh_xml(mesh)}</mesh></object>'
            )
            dx = offset[0] - base_offset[0]
            dy = offset[1] - base_offset[1]
            dz = offset[2] - base_offset[2]
            component_transform = (
                f' transform="1 0 0 0 1 0 0 0 1 {dx:.4f} {dy:.4f} {dz:.4f}"'
                if abs(dx) + abs(dy) + abs(dz) > 1e-6
                else ""
            )
            model_settings.append(
                f'<object id="{oid}"><metadata key="name" value="{_escape(name)}"/>'
                f'<metadata key="extruder" value="{color_slots.get(color, 1)}"/></object>'
            )
            component_xml.append(f'<component objectid="{oid}"{component_transform} />')
        parent_id = next_id
        next_id += 1
        components = "".join(component_xml)
        objects.append(
            f'<object id="{parent_id}" type="model" name="{_escape(base_name)}">'
            f'<components>{components}</components></object>'
        )
        tx, ty, tz = base_offset
        items.append(f'<item objectid="{parent_id}" transform="1 0 0 0 1 0 0 0 1 {tx:.4f} {ty:.4f} {tz:.4f}"/>')
        model_settings.append(
            f'<object id="{parent_id}"><metadata key="name" value="{_escape(base_name)}"/>'
            f'<metadata key="extruder" value="{color_slots.get(base_color, 1)}"/></object>'
        )

    model = f'''<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="es-ES" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">
  <metadata name="Title">{_escape(title)}</metadata>
  <metadata name="Application">CalicoCutters</metadata>
  <resources><basematerials id="1">{materials}</basematerials>{''.join(objects)}</resources>
  <build>{''.join(items)}</build>
</model>'''
    content_types = '''<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>
  <Default Extension="config" ContentType="application/xml"/>
</Types>'''
    rels = '''<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>
</Relationships>'''
    bambu_settings = (
        '<?xml version="1.0" encoding="UTF-8"?>\n<config>\n'
        + "\n".join(model_settings)
        + "\n</config>"
    )
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("3D/3dmodel.model", model)
        z.writestr("Metadata/model_settings.config", bambu_settings)
    return buf.getvalue()
